package com.example.server.tcpserver;

import android.content.Context;
import android.os.Handler;
import android.util.Log;
import android.widget.TextView;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
public class SocketServerThread extends Thread {

    static final int SocketServerPORT = 8080;
    int count = 0;
    Context context;
    private Handler handler;

    TextView info, msg;
    String message = "";
    ServerSocket serverSocket;


    public SocketServerThread(Context cntxt, TextView msg, TextView informationText) {
        this.context = cntxt;
        handler = new Handler(context.getMainLooper());
        this.info = informationText;
        this.msg = msg;
    }

    private void runOnUiThread(Runnable r) {
        handler.post(r);
    }

    @Override
    public void run() {
        try {
            serverSocket = new ServerSocket(SocketServerPORT);

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    info.setText("I'm waiting here: "
                            + serverSocket.getLocalPort());
                    msg.setText(message);
                }
            });

            while (true) {
                Socket socket = serverSocket.accept();
                count++;
                message += "#" + count + " from " + socket.getInetAddress()
                        + ":" + socket.getPort() + "\n";

                Log.d("TAG", "SocketServerThread message = " + message);
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        msg.setText(message);
//                    }
//                });

                SocketServerReplyThread socketServerReplyThread = new SocketServerReplyThread(
                        socket, count,
                        context, msg);
                socketServerReplyThread.run();

            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}